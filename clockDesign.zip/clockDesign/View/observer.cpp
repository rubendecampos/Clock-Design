#include "observer.h"

//Constructor
Observer::Observer()
{

}
